/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mthree.floororder;

import com.mthree.floororder.controller.FloorOrderController;
import com.mthree.floororder.dao.FloorOrderAuditDao;
import com.mthree.floororder.dao.FloorOrderAuditDaoImpl;
import com.mthree.floororder.dao.FloorOrderDao;
import com.mthree.floororder.dao.FloorOrderDaoFileImpl;
import com.mthree.floororder.dao.FloorOrderPersistenceException;
import com.mthree.floororder.service.FloorOrderServiceLayer;
import com.mthree.floororder.service.FloorOrderServiceLayerImpl;
import com.mthree.floororder.ui.FloorOrderView;
import com.mthree.floororder.ui.UserIO;
import com.mthree.floororder.ui.UserIOConsoleImpl;

/**
 *
 * @author Josef
 */
public class App {
    public static void main(String[] args)
    {
        try {
        UserIO myIo = new UserIOConsoleImpl();
            FloorOrderView myView = new FloorOrderView(myIo);
            FloorOrderDao myDao = new FloorOrderDaoFileImpl();
            FloorOrderAuditDao myAudit = new FloorOrderAuditDaoImpl();
            FloorOrderServiceLayer myService = new FloorOrderServiceLayerImpl(myAudit, myDao);
            FloorOrderController controller =
                new FloorOrderController(myService, myView);
        controller.run();
        }
        catch (FloorOrderPersistenceException e)
        {
            
        }
    }
}
